
from django.contrib import messages
from basedatos.logic  import *
from django.http import HttpResponse
from django.template import Template, Context
from django.template import loader
from django.shortcuts import redirect, render
from basedatos import models
from datetime import date

# Create your views here.
def actualizacionVe(request):
  return render(request, "actualizacionVe.html") 


def regvehiculo(request):
  if request.method == 'POST':
    matricula = request.POST['Matricula']
    modelo = request.POST['Modelo']
    tipo = request.POST['Tipo']
    soat = request.POST['Soat']
    tecnicomecanica = request.POST['Tecnicomecanica']
    servicio = request.POST['Servicio']
    marca = request.POST['Marca']
    vim = request.POST['Vim']
    prenda = request.POST['Prenda']
    tipocombustible = request.POST['tipoCombustible']
    historial = request.POST['Historial']
    cedula = request.POST['input_cedula']

    print(matricula, modelo, tipo, soat, tecnicomecanica, servicio, marca, vim, prenda, tipocombustible, historial, cedula) 

    if verificarPrevioRegistro('vehiculo', matricula):
      messages.info(request,'Este vehículo ya se encuentra registrado')
      return render(request, "regvehiculo.html")

    if not usuarioExiste(cedula):
      messages.info(request,'Por favor registre el usuario para poder registrar el vehiculo')
      return render(request, "regvehiculo.html")

    if not placaValida(matricula, servicio):
      messages.info(request,'Placa inválida')
      return render(request, "regvehiculo.html")

    else:
      user = Usuario.objects.get(identificacion=cedula)
      ins= models.Vehiculo(matricula = matricula, modelo= modelo, tipo= tipo, SOAT= soat,
      tecnicomecanica= tecnicomecanica, servicio=servicio, marca= marca, VIM= vim, prendas= prenda,
      tipocombustible= tipocombustible, historial= historial, idusuario = user)
      ins.save()
      messages.info(request, 'Registro exitoso!') 

  return render(request, "regvehiculo.html") 

def registroLicencia(request):
  if request.method == 'POST':
    nombre = request.POST['Nombre']
    apellido = request.POST['Apellido']
    id = request.POST['Identificacion']
    expedicion = request.POST['Expedicion']
    vencimiento = request.POST['fechaVencimiento']
    categoria = request.POST['Categoria']
    rh = request.POST['rh']
    restricciones = request.POST['Restricciones']
    organismotransitoexpididor = request.POST['organismoExpedidor']
    fotolicencia = request.POST['fotoLicencia']


    print(nombre, apellido, id, expedicion, vencimiento, categoria, rh, restricciones, organismotransitoexpididor ,fotolicencia)

    if verificarPrevioRegistro('licencia', id):
      #print('Usuario ya registrado')
      messages.info(request,'Este usuario ya tiene una licencia asociada')
      return render(request, "registroLicencia.html")

    if not usuarioExiste(id):
      
      messages.info(request,'Por favor registre el usuario para poder registrar la licencia')
      return render(request, "registroLicencia.html")

  
    ins = models.Licencia(identificacion=id, nombre=nombre, apellido=apellido, fechaexpedicion=expedicion, 
    fechavencimiento = vencimiento, categoria= categoria, rh = rh, restricciones = restricciones,
    organismotransitoexpididor=organismotransitoexpididor, fotolicencia = fotolicencia)
    ins.save()
    messages.info(request, 'Registro exitoso!')

  return render(request, "registroLicencia.html") 

def registroUsuarios(request): 
  if request.method == 'POST':
    nombre = request.POST['Nombre']
    apellido = request.POST['Apellido']
    telefono = request.POST['Telefono']
    direccion = request.POST['Direccion']
    id = request.POST['Identificacion']
    expedicion = request.POST['Expedicion']
    nacimiento = request.POST['Nacimiento']
    email = request.POST['Email']
    contraseña = request.POST['Contraseña']
    
    print(nombre, apellido, telefono, direccion, id, expedicion, nacimiento, email, contraseña)

    #print(verificarPrevioRegistro('usuario', id))

    if verificarPrevioRegistro('usuario', id):
      #print('Usuario ya registrado')
      messages.info(request,'Usuario ya registrado')
      return render(request, "registroUsuarios.html")

    print(verificarEdad(nacimiento))
    if verificarEdad(nacimiento) <= 16:
      #print('Usuario no cumple edad minima')
      messages.info(request,'Usuario no cumple edad mínima')
      return render(request, "registroUsuarios.html")

    ins = models.Usuario(identificacion=id, nombre=nombre, apellido=apellido, direccion=direccion, 
    telefono=telefono, correo=email, fechaexpediciondocumento=expedicion, fechanacimiento=nacimiento, contraseña=contraseña)
    ins.save()
    messages.info(request, 'Registro exitoso!') 
    return render(request, "registroUsuarios.html") 
     
  return render(request, "registroUsuarios.html")

  

def indexi(request):
  return render(request, "indexi.html")

def cuenta(request):
  if request.method == 'POST':
        try:
          detalleUsuario = models.Usuario.objects.get(correo =request.POST['correo'], contraseña = request.POST['clave'])
          print("Usuario=", detalleUsuario)
          request.session['correo'] = detalleUsuario.correo
          return render(request, "indexi.html")

        except models.Usuario.DoesNotExist as e:
          messages.success(request, "Nombre de usuario y/o contraseña no son correctos")

  return render(request, "cuenta.html")

def logout_request(request):
      messages.info(request,"Se ha cerrado la sesión")
      return render(request, "index.html")

